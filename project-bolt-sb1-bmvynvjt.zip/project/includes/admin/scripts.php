<!-- Bootstrap 5 CDN JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<!-- Custom Admin JS -->
<script src="/dataspeed/public/assets/js/admin.js"></script>
</body>
</html>